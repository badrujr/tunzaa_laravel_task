<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ShortUrlController;
use App\Http\Controllers\ShortUserController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::middleware([
    'auth:sanctum',
    config('jetstream.auth_session'),
    'verified'
])->group(function () {
    Route::get('/dashboard', function () {
        return view('dashboard');
    })->name('dashboard');
});
Route::get('/links', [ShortUserController::class,'index'])->name('user.links')->middleware('auth');

Route::post('/short', [ShortUrlController::class,'short'])->name('short.url');
Route::get('/{code}', [ShortUrlController::class,'show'])->name('short.show');
Route::get('/delete/{id}',[ShortUserController::class,'delete']);
Route::get('/edit/{id}',[ShortUserController::class,'edit']);
Route::post('/editurl/{id}',[ShortUserController::class,'editurl']);

