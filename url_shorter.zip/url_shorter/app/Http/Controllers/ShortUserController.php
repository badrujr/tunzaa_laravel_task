<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Shorturl;
use App\Models\UrlShorter;

class ShortUserController extends Controller
{
    public function index(){
        $links = auth()->user()->links;
        return view('links.index',compact('links'));
    }
    public function delete($id){
        $remove = shorturl::find($id);
        $remove->delete();
        return redirect()->back();
    }
    public function edit($id){
        $update = shorturl::find($id);
        return view('links.edit',compact('update'));
    }
    public function editurl(Request $request, $id){
        $url = shorturl::find($id);
        $short_url = base_convert($url->id, 10,36);
        $url->original_url=$request->original_url;
        $url->short_url=$short_url;

    $url->save();
        return back();
        }
}
