<!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Dashboard') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <h1> link list</h1>
            <table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Original url</th>
      <th scope="col">Short url</th>
      <th scope="col">Visits</th>
      <th scope="col">Edit</th>
      <th scope="col">Delete</th>
    </tr>
  </thead>
  <tbody>
    @foreach($links as $link)
    <tr>
      <th>{{$link->id}}</th>
      <td><a href="{{$link->original_url}}">{{$link->original_url}}</a></td>
      <td><a href="{{url($link->short_url)}}">{{url($link->short_url)}}</a></td>
      <td>{{$link->visits}}</td>
      <td><a href="{{url('edit',$link->id)}}">Edit</a></td>
      <td><a href="{{url('delete',$link->id)}}">Delete</a></td>
    </tr>
    @endforeach
   

  </tbody>
</table>
            <hr/>
        </div>
    </div>
</x-app-layout>
<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>